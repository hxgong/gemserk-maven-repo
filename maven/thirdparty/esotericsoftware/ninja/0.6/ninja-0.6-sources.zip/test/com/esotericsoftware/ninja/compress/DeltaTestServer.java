
package com.esotericsoftware.ninja.compress;

import static com.esotericsoftware.ninja.Log.*;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Listener;
import com.esotericsoftware.ninja.Network;
import com.esotericsoftware.ninja.Server;
import com.esotericsoftware.ninja.serialize.FieldSerializer;

public class DeltaTestServer {
	public DeltaTestServer () throws Exception {
		Network.register(short[].class);
		Network.register(SomeData.class, new DeltaCompressor(new FieldSerializer(), 2048, 4, true, true));
		Network.register(SomeOtherData.class);

		final SomeData data = new SomeData();
		data.text = "some text here aaaaaaabbbbbccccc";
		data.stuff = new short[] {1, 2, 3, 4, 5, 6, 7, 8};

		final Server server = new Server();
		new Thread(server).start();
		server.bind(54555, 54777);
		server.addListener(new Listener() {
			public void connected (Connection connection) {
				data.stuff[3] = 4;
				server.sendToAllTCP(data);

				data.stuff[3] = 123;
				connection.sendTCP(data);

				data.stuff[3] = 125;
				connection.sendTCP(data);

				SomeOtherData someOtherData = new SomeOtherData();
				someOtherData.data = data; // This child object will be delta compressed.
				someOtherData.text = "abcdefghijklmnop";
				connection.sendTCP(someOtherData);
			}

			public void received (Connection connection, Object object) {
			}
		});
	}

	static public class SomeData {
		public String text;
		public short[] stuff;
	}

	static public class SomeOtherData {
		public String text;
		public SomeData data;
	}

	public static void main (String[] args) throws Exception {
		level = TRACE;
		new DeltaTestServer();
	}
}
