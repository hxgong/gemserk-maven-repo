
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;


public class SimpleTestServer {
	static public class SomeRequest {
		public String text;

		public String toString () {
			return "SomeRequest";
		}
	}

	static public class SomeReply {
		public String text;

		public String toString () {
			return "SomeReply";
		}
	}

	public static void main (String[] args) throws Exception {
		level = DEBUG;

		Network.register(SomeRequest.class);
		Network.register(SomeReply.class);
		Network.register(short[].class);

		Server server = new Server();
		new Thread(server).start();
		server.bind(54555, 54777);
		server.addListener(new Listener() {
			public void connected (Connection connection) {
				connection.sendTCP("weee");
				connection.sendUDP(1203f);
			}

			public void received (Connection connection, Object object) {
				if (object instanceof SomeRequest) {
					SomeRequest request = (SomeRequest)object;
					System.out.println("Request: " + request.text);

					SomeReply reply = new SomeReply();
					reply.text = "Thanks!";
					connection.sendTCP(reply);
				}
			}
		});
	}
}
