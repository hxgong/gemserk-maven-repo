
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;

public class BroadcastTestServer {
	public static void main (String[] args) throws IOException {
		level = DEBUG;

		Server server = new Server();
		new Thread(server).start();
		server.bind(54555, 54777);
	}
}
