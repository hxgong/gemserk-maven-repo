
package com.esotericsoftware.ninja.compress;

import static com.esotericsoftware.ninja.Log.*;

import java.util.ArrayList;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Listener;
import com.esotericsoftware.ninja.Network;
import com.esotericsoftware.ninja.Server;
import com.esotericsoftware.ninja.serialize.CollectionSerializer;
import com.esotericsoftware.ninja.serialize.FieldSerializer;

public class DeflateTestServer {
	public DeflateTestServer () throws Exception {
		Network.register(short[].class);
		Network.register(SomeData.class, new DeflateCompressor(new FieldSerializer()));
		Network.register(ArrayList.class, new CollectionSerializer());

		final SomeData data = new SomeData();
		data.text = "some text here aaaaaaaaaabbbbbbbbbbbcccccccccc";
		data.stuff = new short[] {1, 2, 3, 4, 5, 6, 7, 8};

		final ArrayList a = new ArrayList();
		a.add(12);
		a.add(null);
		a.add(34);

		final Server server = new Server();
		new Thread(server).start();
		server.bind(54555, 54777);
		server.addListener(new Listener() {
			public void connected (Connection connection) {
				server.sendToAllTCP(data);
				connection.sendTCP(data);
				connection.sendTCP(a);
			}
		});
	}

	static public class SomeData {
		public String text;
		public short[] stuff;
	}

	public static void main (String[] args) throws Exception {
		level = TRACE;
		new DeflateTestServer();
	}
}
