
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import com.esotericsoftware.ninja.SimpleTestServer.SomeReply;
import com.esotericsoftware.ninja.SimpleTestServer.SomeRequest;

public class SimpleTestClient {
	public static void main (String[] args) throws Exception {
		level = DEBUG;

		Network.register(SomeRequest.class);
		Network.register(SomeReply.class);
		Network.register(short[].class);

		final Client client = new Client();
		new Thread(client).start();
		client.addListener(new Listener() {
			public void connected (Connection connection) {
				client.sendUDP("This is freaking sweet!");
				client.sendTCP("This is freaking sweet!");
				client.sendTCP("meow2");
				client.sendUDP("aaaaaabbbbbbccccccddddddeeeeeeffffffgggggghhhhhh");
				client.sendTCP("aaaaaabbbbbbccccccddddddeeeeeeffffffgggggghhhhhh");
				client.sendUDP(4);
				client.sendTCP(new short[] {1, 2, 3});
			}

			public void received (Connection connection, Object object) {
				if (object instanceof SomeReply) {
					SomeReply reply = (SomeReply)object;
					System.out.println("Reply: " + reply.text);
				}
			}
		});

		client.connect(5000, "localhost", 54555, 54777);

		client.sendTCP("meow1");

		SomeRequest request = new SomeRequest();
		request.text = "Here is the request!";
		client.sendTCP(request);
	}
}
