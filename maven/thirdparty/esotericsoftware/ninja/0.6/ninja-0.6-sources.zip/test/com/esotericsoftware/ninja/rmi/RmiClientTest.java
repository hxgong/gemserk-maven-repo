
package com.esotericsoftware.ninja.rmi;

import java.io.IOException;

import com.esotericsoftware.ninja.Client;
import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Listener;
import com.esotericsoftware.ninja.Log;
import com.esotericsoftware.ninja.Network;
import com.esotericsoftware.ninja.rmi.RmiServerTest.MessageWithTestObject;
import com.esotericsoftware.ninja.rmi.RmiServerTest.TestObject;
import com.esotericsoftware.ninja.rmi.RmiServerTest.TestObjectImpl;

public class RmiClientTest {
	public static void main (String[] args) throws IOException {
		Log.level = Log.TRACE;
		Network.register(TestObject.class);
		Network.register(MessageWithTestObject.class);
		ObjectSpace.registerClasses();

		Client client = new Client();

		ObjectSpace objectSpace = new ObjectSpace(client);
		final TestObjectImpl testObject = new TestObjectImpl();
		objectSpace.register((short)12, testObject);

		new Thread(client).start();
		client.addListener(new Listener() {
			public void connected (final Connection connection) {
				RmiServerTest.runTest(connection, 42);
			}

			public void received (Connection connection, Object object) {
				if (!(object instanceof MessageWithTestObject)) return;
				MessageWithTestObject m = (MessageWithTestObject)object;
				System.out.println(testObject.value);
				System.out.println(((TestObjectImpl)m.testObject).value);
			}
		});
		client.connect(5000, "localhost", 54555);
	}
}
