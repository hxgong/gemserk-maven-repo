
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

public class PingPongTestClient {
	public static void main (String[] args) throws Exception {
		level = DEBUG;

		final Client client = new Client();
		new Thread(client).start();
		client.addListener(new Listener() {
			public void received (Connection connection, Object object) {
				if (object.equals("pingTCP"))
					connection.sendTCP("pongTCP");
				else
					connection.sendUDP("pongUDP");

			}
		});

		client.connect(5000, "localhost", 54555, 54777);
	}
}
