
package com.esotericsoftware.ninja.compress;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;
import java.util.ArrayList;

import com.esotericsoftware.ninja.Client;
import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Listener;
import com.esotericsoftware.ninja.Network;
import com.esotericsoftware.ninja.compress.DeltaTestServer.SomeData;
import com.esotericsoftware.ninja.serialize.CollectionSerializer;
import com.esotericsoftware.ninja.serialize.FieldSerializer;

public class DeflateTestClient {
	public DeflateTestClient () throws IOException {
		Network.register(short[].class);
		Network.register(SomeData.class, new DeflateCompressor(new FieldSerializer()));
		Network.register(ArrayList.class, new CollectionSerializer());

		Client client = new Client();
		new Thread(client).start();
		client.addListener(new Listener() {
			public void received (Connection connection, Object object) {
				if (object instanceof SomeData) {
					SomeData data = (SomeData)object;
					System.out.println(data.stuff[3]);
				}
			}
		});
		client.connect(5000, "localhost", 54555, 54777);
	}

	public static void main (String[] args) throws IOException {
		level = TRACE;
		new DeflateTestClient();
	}
}
