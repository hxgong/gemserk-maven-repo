
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;
import java.net.InetAddress;

public class BroadcastTestClient {
	public static void main (String[] args) throws IOException {
		level = DEBUG;

		InetAddress host = Network.discoverHost(54777, 2000);
		if (host == null) {
			System.out.println("No servers found.");
			return;
		}

		Client client = new Client();
		new Thread(client).start();
		client.connect(2000, host, 54555, 54777);
	}
}
