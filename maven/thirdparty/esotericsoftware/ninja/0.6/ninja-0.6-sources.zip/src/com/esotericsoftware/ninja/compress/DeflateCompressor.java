
package com.esotericsoftware.ninja.compress;

import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;

/**
 * Compresses and decompresses using the "deflate" algorithm.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class DeflateCompressor extends ByteArrayCompressor {
	private Deflater deflater;
	private Inflater inflater;

	/**
	 * @see ByteArrayCompressor#ByteArrayCompressor(Serializer)
	 */
	public DeflateCompressor (Serializer serializer) {
		super(serializer);
		this.deflater = new Deflater();
		this.inflater = new Inflater();
	}

	/**
	 * @see ByteArrayCompressor#ByteArrayCompressor(Serializer, int)
	 */
	public DeflateCompressor (Serializer serializer, int bufferSize, Deflater deflater, Inflater inflater) {
		super(serializer, bufferSize);
		this.deflater = deflater;
		this.inflater = inflater;
	}

	public int compress (Connection connection, int inputLength) {
		deflater.reset();
		deflater.setInput(inputBuffer, 0, inputLength);
		deflater.finish();
		return deflater.deflate(outputBuffer);
	}

	public int decompress (Connection connection, int inputLength) throws SerializationException {
		inflater.reset();
		inflater.setInput(inputBuffer, 0, inputLength);
		try {
			return inflater.inflate(outputBuffer);
		} catch (DataFormatException ex) {
			throw new SerializationException("Error inflating data.", ex);
		}
	}
}
