
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.esotericsoftware.ninja.compress.Compressor;
import com.esotericsoftware.ninja.serialize.ArraySerializer;
import com.esotericsoftware.ninja.serialize.BooleanSerializer;
import com.esotericsoftware.ninja.serialize.ByteSerializer;
import com.esotericsoftware.ninja.serialize.CharSerializer;
import com.esotericsoftware.ninja.serialize.CollectionSerializer;
import com.esotericsoftware.ninja.serialize.CustomSerialization;
import com.esotericsoftware.ninja.serialize.CustomSerializer;
import com.esotericsoftware.ninja.serialize.DoubleSerializer;
import com.esotericsoftware.ninja.serialize.EnumSerializer;
import com.esotericsoftware.ninja.serialize.FieldSerializer;
import com.esotericsoftware.ninja.serialize.FloatSerializer;
import com.esotericsoftware.ninja.serialize.IntSerializer;
import com.esotericsoftware.ninja.serialize.LongSerializer;
import com.esotericsoftware.ninja.serialize.MapSerializer;
import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;
import com.esotericsoftware.ninja.serialize.ShortSerializer;
import com.esotericsoftware.ninja.serialize.StringSerializer;
import com.esotericsoftware.ninja.util.ShortHashMap;

/**
 * Registers classes to be sent across the network.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class Network {
	static private final ShortHashMap<RegisteredClass> idToRegisteredClass = new ShortHashMap(64);
	static private final HashMap<Class, RegisteredClass> classToRegisteredClass = new HashMap(64);
	static private final byte ID_NULL_OBJECT = 0;
	static private short nextClassID = 1;

	static private final FieldSerializer fieldSerializer = new FieldSerializer();
	static private final CustomSerializer customSerializer = new CustomSerializer();
	static private final ArraySerializer arraySerializer = new ArraySerializer();
	static private final EnumSerializer enumSerializer = new EnumSerializer();
	static private final CollectionSerializer collectionSerializer = new CollectionSerializer();
	static private final MapSerializer mapSerializer = new MapSerializer();

	static {
		// Primitives.
		register(boolean.class, nextClassID++, new BooleanSerializer()).setCanBeNull(false);
		register(byte.class, nextClassID++, new ByteSerializer()).setCanBeNull(false);
		register(char.class, nextClassID++, new CharSerializer()).setCanBeNull(false);
		register(short.class, nextClassID++, new ShortSerializer()).setCanBeNull(false);
		register(int.class, nextClassID++, new IntSerializer()).setCanBeNull(false);
		register(long.class, nextClassID++, new LongSerializer()).setCanBeNull(false);
		register(float.class, nextClassID++, new FloatSerializer()).setCanBeNull(false);
		register(double.class, nextClassID++, new DoubleSerializer()).setCanBeNull(false);
		// Primitive wrappers.
		register(Boolean.class, nextClassID++, new BooleanSerializer());
		register(Byte.class, nextClassID++, new ByteSerializer());
		register(Character.class, nextClassID++, new CharSerializer());
		register(Short.class, nextClassID++, new ShortSerializer());
		register(Integer.class, nextClassID++, new IntSerializer());
		register(Long.class, nextClassID++, new LongSerializer());
		register(Float.class, nextClassID++, new FloatSerializer());
		register(Double.class, nextClassID++, new DoubleSerializer());
		// Other.
		register(String.class, nextClassID++, new StringSerializer());
		// Framework messages.
		register(RegisterTCP.class, nextClassID++, fieldSerializer);
		register(RegisterUDP.class, nextClassID++, fieldSerializer);
		register(KeepAlive.class, nextClassID++, fieldSerializer);
		register(DiscoverHost.class, nextClassID++, fieldSerializer);
	}

	static private Serializer register (Class type, short id, Serializer serializer) {
		RegisteredClass registeredClass = new RegisteredClass();
		registeredClass.type = type;
		registeredClass.id = id;
		registeredClass.serializer = serializer;
		idToRegisteredClass.put(id, registeredClass);
		classToRegisteredClass.put(type, registeredClass);
		return serializer;
	}

	/**
	 * Registers a class to be transferred over the network. The exact same classes and serializers must be registered on both the
	 * {@link Client} and the {@link Server}, in exactly the same order.
	 * <p>
	 * Clases should be registered before any connections are opened. This allows an object's type to be transferred as an ID.
	 * Unregistered classes cannot be transferred.
	 * <p>
	 * By default primitive types, primitive wrappers, and java.lang.String are registered. To transfer ANY other classes over the
	 * network, those classes must be registered. Note that even JDK classes like ArrayList, HashMap, etc must be registered. Also,
	 * array classes such as "int[].class" or "short[][].class" must be registered.
	 * <p>
	 * The {@link Serializer} specified will be used to serialize and deserialize objects of the specified type. Note that a
	 * serializer can be wrapped with a {@link Compressor}.
	 * 
	 * @see #register(Class)
	 * @see Serializer
	 * @see Compressor
	 */
	static public void register (Class type, Serializer serializer) {
		if (type == null) throw new IllegalArgumentException("type cannot be null.");
		if (serializer == null) throw new IllegalArgumentException("serializer cannot be null.");
		short id;
		RegisteredClass existingRegisteredClass = classToRegisteredClass.get(type);
		if (existingRegisteredClass != null)
			id = existingRegisteredClass.id;
		else
			id = nextClassID++;
		register(type, id, serializer);
		if (level <= TRACE) {
			String name = type.getName();
			if (type.isArray()) {
				Class elementClass = ArraySerializer.getElementClass(type);
				StringBuilder buffer = new StringBuilder(16);
				for (int i = 0, n = ArraySerializer.getDimensionCount(type); i < n; i++)
					buffer.append("[]");
				name = elementClass.getName() + buffer;
			}
			trace("Registered class " + (nextClassID - 1) + ": " + name + " (" + serializer.getClass().getName() + ")");
		}
	}

	/**
	 * Reisters the class, automatically determining the serializer to use. A serializer will be chosen according to this table:
	 * <p>
	 * <table>
	 * <tr>
	 * <th>Type</th>
	 * <th>Serializer</th>
	 * </tr>
	 * <tr>
	 * <td>array (any number of dimensions)</td>
	 * <td>{@link ArraySerializer}</td>
	 * </tr>
	 * <tr>
	 * <td>{@link Enum}</td>
	 * <td>{@link EnumSerializer}</td>
	 * </tr>
	 * <tr>
	 * <td>{@link Collection}</td>
	 * <td>{@link CollectionSerializer}</td>
	 * </tr>
	 * <tr>
	 * <td>{@link Map}</td>
	 * <td>{@link MapSerializer}</td>
	 * </tr>
	 * <tr>
	 * <td>{@link CustomSerialization}</td>
	 * <td>{@link CustomSerializer}</td>
	 * </tr>
	 * <tr>
	 * <td>any other class</td>
	 * <td>{@link FieldSerializer}</td>
	 * </tr>
	 * </table>
	 * <p>
	 * Note that some serializers have alternate constructors that make transfers more efficient in some cases (eg,
	 * {@link CollectionSerializer#CollectionSerializer(Class, boolean)}).
	 * 
	 * @see #register(Class, Serializer)
	 */
	static public void register (Class type) {
		if (type == null) throw new IllegalArgumentException("type cannot be null.");
		Serializer serializer;
		if (type.isArray())
			serializer = arraySerializer;
		else if (CustomSerialization.class.isAssignableFrom(type))
			serializer = customSerializer;
		else if (Collection.class.isAssignableFrom(type))
			serializer = collectionSerializer;
		else if (Map.class.isAssignableFrom(type))
			serializer = mapSerializer;
		else if (Enum.class.isAssignableFrom(type))
			serializer = enumSerializer;
		else {
			serializer = fieldSerializer;
		}
		register(type, serializer);
	}

	static public RegisteredClass getRegisteredClass (Class type) {
		if (type == null) throw new IllegalArgumentException("type cannot be null.");
		RegisteredClass registeredClass = classToRegisteredClass.get(type);
		if (registeredClass == null) {
			// If a Proxy class, treat it like an InvocationHandler because the concrete class for a proxy is generated.
			if (Proxy.isProxyClass(type)) return getRegisteredClass(InvocationHandler.class);
			if (type.isArray()) {
				Class elementClass = ArraySerializer.getElementClass(type);
				StringBuilder buffer = new StringBuilder(16);
				for (int i = 0, n = ArraySerializer.getDimensionCount(type); i < n; i++)
					buffer.append("[]");
				throw new IllegalArgumentException("Class is not registered: " + elementClass.getName() + buffer);
			}
			throw new IllegalArgumentException("Class is not registered: " + type.getName());
		}
		return registeredClass;
	}

	static public RegisteredClass getRegisteredClass (short classID) {
		RegisteredClass registeredClass = idToRegisteredClass.get(classID);
		if (registeredClass == null) throw new IllegalArgumentException("Class ID is not registered: " + classID);
		return registeredClass;
	}

	/**
	 * Holds the registration information for a registered class.
	 */
	static public class RegisteredClass {
		public Class type;
		public short id;
		public Serializer serializer;
	}

	/**
	 * Writes the ID of the specified class to the buffer.
	 * @param type Can be null (writes a special class ID for a null object).
	 * @return The class that was written.
	 * @throws SerializationException if the class could not be written.
	 */
	static public RegisteredClass writeClass (Class type, ByteBuffer buffer) throws SerializationException {
		RegisteredClass registeredClass = getRegisteredClass(type);
		ShortSerializer.put(buffer, registeredClass.id, true);
		if (level <= TRACE) trace("Wrote class " + registeredClass.id + ": " + type.getName());
		return registeredClass;
	}

	/**
	 * Reads the class ID from the buffer and returns the registered information.
	 * @return The class that was read, or null if the data read from the buffer represented a null object.
	 * @throws SerializationException if the class could not be read.
	 */
	static public RegisteredClass readClass (ByteBuffer buffer) throws SerializationException {
		short classID = ShortSerializer.get(buffer, true);
		if (classID == ID_NULL_OBJECT) {
			if (level <= TRACE) trace("Read object: null");
			return null;
		}
		RegisteredClass registeredClass = idToRegisteredClass.get(classID);
		if (registeredClass == null) throw new SerializationException("Encountered unregistered class ID: " + classID);
		if (level <= TRACE) trace("Read class " + classID + ": " + registeredClass.type.getName());
		return registeredClass;
	}

	/**
	 * Writes the object's class ID and then the object to the buffer. This method should be used when the class will not be known
	 * at the time the object is to be read from the buffer. Otherwise
	 * {@link Serializer#writeObject(Connection, Object, ByteBuffer)} should be used.
	 * @param object Can be null (writes a special class ID for a null object and no object data).
	 * @throws SerializationException if the object could not be written.
	 */
	static public void writeClassAndObject (Connection connection, Object object, ByteBuffer writeBuffer)
		throws SerializationException {
		writeClassAndObject(connection, object, writeBuffer, false);
	}

	static void writeClassAndObject (Connection connection, Object object, ByteBuffer writeBuffer, boolean lengthKnown)
		throws SerializationException {
		if (object == null) {
			writeBuffer.put(ID_NULL_OBJECT);
			if (level <= TRACE) trace("Wrote object: null");
			return;
		}
		try {
			RegisteredClass registeredClass = writeClass(object.getClass(), writeBuffer);
			registeredClass.serializer.writeObjectData(connection, writeBuffer, object, lengthKnown);
		} catch (SerializationException ex) {
			throw new SerializationException("Unable to serialize object of type: " + object.getClass().getName(), ex);
		}
	}

	/**
	 * Reads the object's class ID from the buffer and uses the serializer registered for that class to read the object.
	 * @return The deserialized object, or null if the object read from the buffer was a null.
	 * @throws SerializationException if the object could not be read.
	 */
	static public Object readClassAndObject (Connection connection, ByteBuffer readBuffer) throws SerializationException {
		return readClassAndObject(connection, readBuffer, false);
	}

	static Object readClassAndObject (Connection connection, ByteBuffer readBuffer, boolean lengthKnown)
		throws SerializationException {
		RegisteredClass registeredClass = null;
		try {
			registeredClass = readClass(readBuffer);
			if (registeredClass == null) return null;
			return registeredClass.serializer.readObjectData(connection, readBuffer, registeredClass.type, lengthKnown);
		} catch (SerializationException ex) {
			if (registeredClass != null)
				throw new SerializationException("Unable to deserialize object of type: " + registeredClass.type.getName(), ex);
			throw new SerializationException("Unable to deserialize an object.", ex);
		}
	}

	/**
	 * Broadcasts a UDP message on the LAN to discover any running servers.
	 * @param udpPort The UDP port of the server.
	 * @param timeoutMillis The number of milliseconds to wait for a response.
	 * @return the first server found, or null if no server responded.
	 */
	static public InetAddress discoverHost (int udpPort, int timeoutMillis) {
		// TODO - Change to discover multiple hosts.
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket();
			try {
				short classID = classToRegisteredClass.get(DiscoverHost.class).id;
				ByteBuffer dataBuffer = ByteBuffer.allocate(4);
				ShortSerializer.put(dataBuffer, classID, true);
				dataBuffer.flip();
				byte[] data = new byte[dataBuffer.limit()];
				dataBuffer.get(data);
				for (NetworkInterface iface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
					for (InetAddress address : Collections.list(iface.getInetAddresses())) {
						if (!address.isSiteLocalAddress()) continue;
						// Java 1.5 doesn't support getting the subnet mask, so try the two most common.
						byte[] ip = address.getAddress();
						ip[3] = -1; // 255.255.255.0
						socket.send(new DatagramPacket(data, data.length, InetAddress.getByAddress(ip), udpPort));
						ip[2] = -1; // 255.255.0.0
						socket.send(new DatagramPacket(data, data.length, InetAddress.getByAddress(ip), udpPort));
					}
				}
				if (level <= DEBUG) debug("Broadcasted host discovery on port: " + udpPort);

				socket.setSoTimeout(timeoutMillis);
				DatagramPacket packet = new DatagramPacket(new byte[0], 0);
				try {
					socket.receive(packet);
				} catch (SocketTimeoutException ex) {
					if (level <= INFO) debug("Host discovery timed out.");
					return null;
				}
				if (level <= INFO) debug("Discovered server: " + packet.getAddress());
				return packet.getAddress();
			} finally {
				socket.close();
			}
		} catch (IOException ex) {
			if (level <= ERROR) error("Host discovery failed.", ex);
			return null;
		}
	}

	static final KeepAlive keepAlive = new KeepAlive();

	/**
	 * Marker interface to denote that a message is used by the framework and is generally invisible to the developer. Eg, these
	 * messages are only logged at the {@link Log#TRACE} level.
	 */
	static public interface FrameworkMessage {
	}

	/**
	 * Internal message to give the client the server assigned connection ID.
	 */
	static public class RegisterTCP implements FrameworkMessage {
		public short connectionID;

		public String toString () {
			return "RegisterTCP";
		}
	}

	/**
	 * Internal message to give the server the client's UDP port.
	 */
	static public class RegisterUDP implements FrameworkMessage {
		public short connectionID;

		public String toString () {
			return "RegisterUDP";
		}
	}

	/**
	 * Internal message to keep connections alive.
	 */
	static public class KeepAlive implements FrameworkMessage {
		public String toString () {
			return "KeepAlive";
		}
	}

	/**
	 * Internal message to discover running servers.
	 */
	static public class DiscoverHost implements FrameworkMessage {
		public String toString () {
			return "DiscoverHost";
		}
	}
}
