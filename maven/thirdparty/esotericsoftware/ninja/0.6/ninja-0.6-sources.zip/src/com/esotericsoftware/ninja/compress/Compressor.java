
package com.esotericsoftware.ninja.compress;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Network;
import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;

/**
 * Wraps another serializer in order to modify the bytes after they are serialized and before they are deserialized.
 * @see Network#register(Class, Serializer)
 * @author Nathan Sweet <misc@n4te.com>
 */
abstract public class Compressor extends Serializer {
	protected Serializer serializer;
	protected boolean compress, decompress;

	public Compressor (Serializer serializer) {
		this(serializer, true, true);
	}

	public Compressor (Serializer serializer, boolean compress, boolean decompress) {
		this.serializer = serializer;
		this.compress = compress;
		this.decompress = decompress;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {

		if (!compress) {
			serializer.writeObjectData(connection, buffer, object, lengthKnown);
			return;
		}

		int start = buffer.position();
		if (!lengthKnown) {
			start += 2;
			buffer.position(start);
		}

		serializer.writeObjectData(connection, buffer, object, true);
		int end = buffer.position();

		buffer.position(start);
		buffer.limit(end);
		compress(connection, object, buffer);
		if (level <= TRACE) {
			trace("Compressed to " + ((int)((buffer.position() - start) / (float)(end - start) * 10000) / 100f) + "% using: "
				+ getClass().getName());
		}

		if (!lengthKnown) buffer.putShort(start - 2, (short)(buffer.position() - start));
	}

	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {

		if (!decompress) return serializer.readObjectData(connection, buffer, type, lengthKnown);

		int oldLimit = 0;
		if (!lengthKnown) {
			oldLimit = buffer.limit();
			int length = buffer.getShort();
			buffer.limit(buffer.position() + length);
		}

		ByteBuffer decompressedBuffer = decompress(connection, buffer, type);
		if (!lengthKnown) buffer.limit(oldLimit);
		if (level <= TRACE) trace("Decompressed using using: " + getClass().getName());

		return serializer.readObjectData(connection, decompressedBuffer, type, true);
	}

	/**
	 * The compressor should read from the current position to the limit, compress the data, set the limit to the capacity, and
	 * write the compressed data at the same position, leaving the position at the end of the data.
	 * @param connection The connection the data will be sent to.
	 * @param object The data the bytes represent.
	 */
	abstract public void compress (Connection connection, Object object, ByteBuffer buffer) throws SerializationException;

	/**
	 * The compressor should read from the current position to the limit, decompress the data, and return a buffer containing the
	 * decompressed data with the position at the beginning and the limit at the end of the data.
	 * @param connection The connection the data was received from.
	 */
	abstract public ByteBuffer decompress (Connection connection, ByteBuffer buffer, Class type) throws SerializationException;
}
