
package com.esotericsoftware.ninja.serialize;

/**
 * Indicates an error during serialization or deserialization. This is an unrecoverable error and will cause the connection to
 * close.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class SerializationException extends Exception {
	public SerializationException () {
		super();
	}

	public SerializationException (String message, Throwable cause) {
		super(message, cause);
	}

	public SerializationException (String message) {
		super(message);
	}

	public SerializationException (Throwable cause) {
		super(cause);
	}
}
