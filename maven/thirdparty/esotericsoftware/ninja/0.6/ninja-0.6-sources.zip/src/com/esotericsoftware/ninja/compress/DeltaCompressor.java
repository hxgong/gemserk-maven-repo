
package com.esotericsoftware.ninja.compress;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Listener;
import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;
import com.esotericsoftware.ninja.util.ShortHashMap;

/**
 * Caches bytes for the last object sent (per connection) and only transmits deltas on subsequent sends. Also caches bytes for the
 * last object received (per connection), in order to apply deltas received.<br>
 * <br>
 * This class should only be used with TCP. For UDP, more sophisticated caching and a mechanism for the remote system to
 * acknowledge a received delta would be needed (ala Quake 3).
 * @author Nathan Sweet <misc@n4te.com>
 */
public class DeltaCompressor extends Compressor {
	private final int bufferSize;
	private final Delta delta;
	final ShortHashMap<ByteBuffer> connectionToRemoteData = new ShortHashMap(8);
	private final ShortHashMap<ByteBuffer> connectionToLocalData = new ShortHashMap(8);

	private Listener removeBufferListener = new Listener() {
		public void disconnected (Connection connection) {
			connectionToRemoteData.remove(connection.id);
		}
	};

	/**
	 * Creates a DeltaCompressor with a buffer size of 2048, chunk size of 8, compressing sends, and decompressing receives.
	 */
	public DeltaCompressor (Serializer serializer) {
		this(serializer, 2048, 8, true, true);
	}

	/**
	 * @param bufferSize The maximum size a serialized object may be before or after compression.
	 * @param compress If true, sends will be compressed (default).
	 * @param decompress If true, receives will be decompressed (default).
	 * @see Delta#Delta(int, int)
	 */
	public DeltaCompressor (Serializer serializer, int bufferSize, int chunkSize, boolean compress, boolean decompress) {
		super(serializer, compress, decompress);
		this.bufferSize = bufferSize;
		this.compress = compress;
		this.decompress = decompress;
		delta = new Delta(bufferSize, chunkSize);
	}

	public void compress (Connection connection, Object object, ByteBuffer newData) throws SerializationException {
		int start = newData.position();

		ByteBuffer remoteData = connectionToRemoteData.get(connection.id);

		ByteBuffer deltaData = delta.compress(remoteData, newData);

		if (remoteData == null) {
			remoteData = ByteBuffer.allocateDirect(bufferSize);
			connectionToRemoteData.put(connection.id, remoteData);
			connection.addListener(removeBufferListener);
		}
		remoteData.clear();
		newData.position(start);
		remoteData.put(newData);
		remoteData.flip();

		// Replace data.
		newData.position(start);
		newData.limit(newData.capacity());
		newData.put(deltaData);
	}

	public ByteBuffer decompress (Connection connection, ByteBuffer deltaData, Class type) throws SerializationException {
		if (!decompress) return deltaData;

		ByteBuffer localData = connectionToLocalData.get(connection.id);

		ByteBuffer reconstructedData = delta.decompress(localData, deltaData);

		if (localData == null) {
			localData = ByteBuffer.allocateDirect(bufferSize);
			connectionToLocalData.put(connection.id, localData);
			connection.addListener(removeBufferListener);
		}
		localData.clear();
		localData.put(reconstructedData);
		reconstructedData.rewind();
		localData.flip();

		return reconstructedData;
	}
}
