
package com.esotericsoftware.ninja;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

// TODO - Write logger that collects total bytes sent, average compression, etc.

/**
 * A simple, extensible logging system.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class Log {
	static public final int NONE = 6;
	static public final int ERROR = 5;
	static public final int WARN = 4;
	static public final int INFO = 3;
	static public final int DEBUG = 2;
	static public final int TRACE = 1;

	/**
	 * Controls the level of messages that will be logged. Compiling as "final" will cause the compiler to remove all log
	 * statements below the set level.
	 */
	static public int level = INFO;

	/**
	 * The logger that will be used by the static logging methods.
	 */
	static public Logger logger = new Logger();

	private Log () {
	}

	static public void error (String message, Throwable ex) {
		logger.error(message + toString(ex));
	}

	static public void error (String message) {
		logger.error(message);
	}

	static public void warn (String message, Throwable ex) {
		logger.warn(message + toString(ex));
	}

	static public void warn (String message) {
		logger.warn(message);
	}

	static public void info (String message, Throwable ex) {
		logger.info(message + toString(ex));
	}

	static public void info (String message) {
		logger.info(message);
	}

	static public void debug (String message, Throwable ex) {
		logger.debug(message + toString(ex));
	}

	static public void debug (String message) {
		logger.debug(message);
	}

	static public void trace (String message, Throwable ex) {
		logger.trace(message + toString(ex));
	}

	static public void trace (String message) {
		logger.trace(message);
	}

	static public String toString (Throwable ex) {
		StringWriter writer = new StringWriter();
		ex.printStackTrace(new PrintWriter(writer));
		return "\n" + writer.toString().trim();
	}

	/**
	 * Logs to System.out by default. Can be extended and {@link Log#logger} set to handle your own logging.
	 */
	static public class Logger {
		public PrintStream output = System.out;
		public DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");

		public void error (String message) {
			output.println(dateFormat.format(new Date()) + " ERROR: " + message);
		}

		public void warn (String message) {
			output.println(dateFormat.format(new Date()) + "  WARN: " + message);
		}

		public void info (String message) {
			output.println(dateFormat.format(new Date()) + "  INFO: " + message);
		}

		public void debug (String message) {
			output.println(dateFormat.format(new Date()) + " DEBUG: " + message);
		}

		public void trace (String message) {
			output.println(dateFormat.format(new Date()) + " TRACE: " + message);
		}
	}
}
