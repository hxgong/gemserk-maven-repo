
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes a String as UTF-8 bytes.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class StringSerializer extends Serializer {
	public String readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		String s = get(buffer);
		if (level <= TRACE) trace("Read string: " + s);
		return s;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		String s = (String)object;
		put(buffer, s);
		if (level <= TRACE) trace("Wrote string: " + object);
	}

	static public void put (ByteBuffer buffer, String value) {
		try {
			byte[] b = value.getBytes("UTF-8");
			IntSerializer.put(buffer, b.length, true);
			buffer.put(b);
		} catch (UnsupportedEncodingException ignored) {
		}
	}

	static public String get (ByteBuffer buffer) {
		byte[] b = new byte[IntSerializer.get(buffer, true)];
		buffer.get(b);
		try {
			return new String(b, "UTF-8");
		} catch (UnsupportedEncodingException ignored) {
			return "";
		}
	}
}
