
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes a 2 byte char.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class CharSerializer extends Serializer {
	public Character readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		char ch = buffer.getChar();
		if (level <= TRACE) trace("Read char: " + ch);
		return ch;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		buffer.putChar((Character)object);
		if (level <= TRACE) trace("Wrote char: " + object);
	}
}
