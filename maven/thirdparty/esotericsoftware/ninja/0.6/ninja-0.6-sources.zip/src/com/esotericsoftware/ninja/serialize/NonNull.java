
package com.esotericsoftware.ninja.serialize;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Indicates a method's return value or a field can never be null when it is being serialized and deserialized. This optimization
 * allows {@link FieldSerializer} to save 1 byte.
 * @author Nathan Sweet <misc@n4te.com>
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface NonNull {
}
