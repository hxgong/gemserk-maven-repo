
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.esotericsoftware.ninja.Network.FrameworkMessage;
import com.esotericsoftware.ninja.serialize.SerializationException;

/**
 * Represents a TCP and optionally a UDP connection between a {@link Client} and a {@link Server}. Internally manages TCP/UDP
 * connections and hides the differences between the two protocols. If either the TCP or optional UDP connection is closed or
 * errors, both connections are closed.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class Connection {
	/**
	 * The server assigned ID. Will be -1 if this connection is not connected.
	 */
	public short id = -1;

	/**
	 * The optional friendly name. Used in {@link #toString()} and the logging. Useful for providing application specific
	 * identifying information in the logging. May be null.
	 */
	public String name;

	EndPoint endPoint;
	TcpConnection tcp;
	UdpConnection udp;
	SocketAddress udpRemoteAddress;
	private Listener[] listeners = new Listener[0];

	/**
	 * @param bufferSize The maximum size an object may be after serialization.
	 */
	protected Connection (int bufferSize) {
		tcp = new TcpConnection(this, bufferSize);
	}

	/**
	 * Sends the object over the network using TCP.
	 * @see Network#register(Class, com.esotericsoftware.ninja.serialize.Serializer)
	 */
	public void sendTCP (Object object) {
		if (object == null) throw new IllegalArgumentException("object cannot be null.");
		try {
			int length = tcp.send(object);
			if (length == 0) {
				if (level <= TRACE) trace(this + " TCP had nothing to send.");
				return;
			}
			if (level <= DEBUG && !(object instanceof FrameworkMessage)) {
				debug(this + " sent TCP: " + object + " (" + length + ")");
			} else if (level <= TRACE) {
				trace(this + " sent TCP: " + object + " (" + length + ")");
			}
		} catch (SerializationException ex) {
			if (level <= ERROR) error("Error sending TCP with connection: " + this, ex);
			close();
		} catch (IOException ex) {
			if (level <= DEBUG) {
				if (id != -1)
					debug("Unable to send TCP with connection: " + this, ex);
				else
					debug("Unable to send TCP.", ex);
			}
		}
	}

	/**
	 * Sends the object over the network using UDP.
	 * @see Network#register(Class, com.esotericsoftware.ninja.serialize.Serializer)
	 * @throws IllegalStateException if this connection was not opened with both TCP and UDP.
	 */
	public void sendUDP (Object object) {
		if (object == null) throw new IllegalArgumentException("object cannot be null.");
		try {
			SocketAddress address = udpRemoteAddress;
			if (address == null && udp != null) address = udp.connectedAddress;
			if (address == null) throw new IllegalStateException("Connection is not connected via UDP.");
			int length = udp.send(this, object, address);
			if (length == 0) {
				if (level <= TRACE) trace(this + " UDP had nothing to send.");
				return;
			}
			if (level <= DEBUG) {
				if (length != -1) {
					if (level <= DEBUG && !(object instanceof FrameworkMessage)) {
						debug(this + " sent UDP: " + object + " (" + length + ")");
					} else if (level <= TRACE) {
						trace(this + " sent UDP: " + object + " (" + length + ")");
					}
				} else
					debug(this + " was unable to send, UDP socket buffer full.");
			}
		} catch (SerializationException ex) {
			if (level <= ERROR) error("Error sending UDP with connection: " + this, ex);
			close();
		} catch (IOException ex) {
			if (level <= DEBUG) {
				if (id != -1)
					debug("Unable to send UDP with connection: " + this, ex);
				else
					debug("Unable to send UDP.", ex);
			}
		}
	}

	public void close () {
		tcp.close();
		if (udp != null && udp.connectedAddress != null) udp.close();
		if (id != -1) {
			notifyDisconnected();
			if (level <= INFO) info(this + " disconnected.");
		}
		id = -1;
	}

	/**
	 * An empty object will be sent if the TCP connection is inactive more than the specified milliseconds. Some network hardware
	 * will close TCP connections if they cease to transmit. Set to zero to disable. Defaults to 59000.
	 */
	public void setKeepAliveTCP (int keepAliveMillis) {
		tcp.keepAliveTime = keepAliveMillis;
	}

	/**
	 * An empty object will be sent if the UDP connection is inactive more than the specified milliseconds. Most network hardware
	 * will close UDP connections if they cease to transmit. Set to zero to disable. Defaults to 19000.
	 */
	public void setKeepAliveUDP (int keepAliveMillis) {
		if (udp == null) throw new IllegalStateException("Not connected via UDP.");
		udp.keepAliveTime = keepAliveMillis;
	}

	/**
	 * If the listener already exists, it is not added again.
	 */
	public void addListener (Listener listener) {
		if (listener == null) throw new IllegalArgumentException("listener cannot be null.");
		Listener[] listeners = this.listeners;
		for (int i = 0, n = listeners.length; i < n; i++)
			if (listener == listeners[i]) return;
		ArrayList<Listener> temp = new ArrayList(Arrays.asList(listeners));
		temp.add(listener);
		this.listeners = temp.toArray(new Listener[temp.size()]);
		if (level <= TRACE) trace("Connection listener added: " + listener.getClass().getName());
	}

	public void removeListener (Listener listener) {
		if (listener == null) throw new IllegalArgumentException("listener cannot be null.");
		HashSet<Listener> temp = new HashSet(Arrays.asList(listeners));
		if (temp.remove(listener)) {
			listeners = temp.toArray(new Listener[temp.size()]);
			if (level <= TRACE) trace("Connection listener removed: " + listener.getClass().getName());
		}
	}

	void notifyConnected () {
		if (level <= INFO) {
			SocketChannel socketChannel = tcp.socketChannel;
			if (socketChannel != null) {
				Socket socket = tcp.socketChannel.socket();
				if (socket != null) {
					InetSocketAddress remoteSocketAddress = (InetSocketAddress)socket.getRemoteSocketAddress();
					if (remoteSocketAddress != null) info(this + " connected: " + remoteSocketAddress.getAddress());
				}
			}
		}
		Listener[] listeners = this.listeners;
		for (int i = 0, n = listeners.length; i < n; i++)
			listeners[i].connected(this);
	}

	void notifyDisconnected () {
		Listener[] listeners = this.listeners;
		for (int i = 0, n = listeners.length; i < n; i++)
			listeners[i].disconnected(this);
	}

	void notifyReceived (Object object) {
		Listener[] listeners = this.listeners;
		for (int i = 0, n = listeners.length; i < n; i++)
			listeners[i].received(this, object);
	}

	/**
	 * Returns the local {@link Client} or {@link Server} to which this connection belongs.
	 */
	public EndPoint getEndPoint () {
		return endPoint;
	}

	public String toString () {
		if (name != null) return name;
		return "Connection " + id;
	}
}
