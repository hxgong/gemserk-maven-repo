
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes an 8 byte long.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class LongSerializer extends Serializer {
	public Long readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		long l = buffer.getLong();
		if (level <= TRACE) trace("Read long: " + l);
		return l;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		buffer.putLong((Long)object);
		if (level <= TRACE) trace("Wrote long: " + object);
	}
}
