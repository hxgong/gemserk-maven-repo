
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.EOFException;
import java.io.IOException;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

import com.esotericsoftware.ninja.serialize.IntSerializer;
import com.esotericsoftware.ninja.serialize.SerializationException;

/**
 * @author Nathan Sweet <misc@n4te.com>
 */
class TcpConnection {
	SocketChannel socketChannel;
	int keepAliveTime = 59000;
	final ByteBuffer readBuffer, writeBuffer;
	private final ByteBuffer writeLengthBuffer = ByteBuffer.allocateDirect(4);
	private final Connection connection;
	private SelectionKey selectionKey;
	private final Object writeLock = new Object();
	private int currentObjectLength;
	private long lastCommunicationTime;

	public TcpConnection (Connection connection, int bufferSize) {
		this.connection = connection;
		readBuffer = ByteBuffer.allocateDirect(bufferSize);
		writeBuffer = ByteBuffer.allocateDirect(bufferSize);
	}

	public SelectionKey accept (Selector selector, SocketChannel socketChannel) throws IOException {
		try {
			close();
			this.socketChannel = socketChannel;
			socketChannel.configureBlocking(false);
			socketChannel.socket().setTcpNoDelay(true);

			selectionKey = socketChannel.register(selector, SelectionKey.OP_READ);

			if (level <= DEBUG)
				debug("Port " + socketChannel.socket().getLocalPort() + "/TCP connected to: "
					+ socketChannel.socket().getRemoteSocketAddress());

			lastCommunicationTime = System.currentTimeMillis();

			return selectionKey;
		} catch (IOException ex) {
			close();
			throw ex;
		}
	}

	public void connect (Selector selector, SocketAddress remoteAddress, int timeout) throws IOException {
		close();
		try {
			SocketChannel socketChannel = selector.provider().openSocketChannel();
			socketChannel.socket().setTcpNoDelay(true);
			socketChannel.socket().bind(null);
			socketChannel.socket().connect(remoteAddress, timeout);
			socketChannel.configureBlocking(false);
			this.socketChannel = socketChannel;

			selectionKey = socketChannel.register(selector, SelectionKey.OP_READ);
			selectionKey.attach(this);

			if (level <= DEBUG)
				debug("Port " + socketChannel.socket().getLocalPort() + "/TCP connected to: "
					+ socketChannel.socket().getRemoteSocketAddress());

			lastCommunicationTime = System.currentTimeMillis();
		} catch (IOException ex) {
			close();
			IOException ioEx = new IOException("Unable to connect to: " + remoteAddress);
			ioEx.initCause(ex);
			throw ioEx;
		}
	}

	public Object readObject () throws IOException, SerializationException {
		SocketChannel socketChannel = this.socketChannel;
		if (socketChannel == null) throw new EOFException("Connection is closed.");
		int bytesRead = socketChannel.read(readBuffer);
		if (bytesRead == -1) throw new EOFException("Connection is closed.");

		lastCommunicationTime = System.currentTimeMillis();

		readBuffer.flip();
		try {
			if (currentObjectLength == 0) {
				if (!readBuffer.hasRemaining()) return null;
				currentObjectLength = IntSerializer.get(readBuffer, true);
				if (currentObjectLength < 0) currentObjectLength += 65536;
				if (currentObjectLength == 0) return null; // Must be a keep alive.
				if (currentObjectLength > readBuffer.capacity())
					throw new SerializationException("Unable to read object larger than read buffer: " + currentObjectLength);
			}
			// Need enough data to read the whole object.
			int length = currentObjectLength;
			if (readBuffer.remaining() < length) return null;
			currentObjectLength = 0;

			int startPosition = readBuffer.position();
			int limit = readBuffer.limit();
			readBuffer.limit(startPosition + length);
			Object object = Network.readClassAndObject(connection, readBuffer, true);
			readBuffer.limit(limit);
			if (readBuffer.position() - startPosition != length)
				throw new SerializationException("Incorrect number of bytes (" + (startPosition + length - readBuffer.position())
					+ " remaining) used to deserialized object: " + object);

			return object;
		} finally {
			readBuffer.compact();
		}
	}

	public void writeOperation () throws IOException {
		synchronized (writeLock) {
			// If it was not a partial write, clear the OP_WRITE flag. Otherwise wait to be notified when more writing can occur.
			if (writeToSocket()) selectionKey.interestOps(SelectionKey.OP_READ);
		}
	}

	private boolean writeToSocket () throws IOException {
		SocketChannel socketChannel = this.socketChannel;
		if (socketChannel == null) throw new EOFException("Connection is closed.");
		writeBuffer.flip();
		while (writeBuffer.hasRemaining())
			if (socketChannel.write(writeBuffer) == 0) break;
		boolean wasFullWrite = !writeBuffer.hasRemaining();
		writeBuffer.compact();

		lastCommunicationTime = System.currentTimeMillis();

		return wasFullWrite;
	}

	/**
	 * This method is thread safe.
	 */
	public int send (Object object) throws IOException, SerializationException {
		SocketChannel socketChannel = this.socketChannel;
		if (socketChannel == null) throw new EOFException("Connection is closed.");
		synchronized (writeLock) {
			int start = writeBuffer.position();
			try {
				Network.writeClassAndObject(connection, object, writeBuffer, true);
			} catch (SerializationException ex) {
				writeBuffer.position(start);
				throw new SerializationException("Unable to serialize object of type: " + object.getClass().getName(), ex);
			}

			// Write data length to socket.
			int dataLength = writeBuffer.position() - start;
			writeLengthBuffer.clear();
			int lengthLength = IntSerializer.put(writeLengthBuffer, dataLength, true);
			writeLengthBuffer.flip();
			while (writeLengthBuffer.hasRemaining())
				if (socketChannel.write(writeLengthBuffer) == 0) break;
			if (writeLengthBuffer.hasRemaining()) {
				// If writing the length failed, shift the object data over.
				int shift = writeLengthBuffer.remaining();
				for (int i = dataLength - 1; i >= 0; i--)
					writeBuffer.put(i + shift, writeBuffer.get(i));
				// Insert the part of the length that failed.
				writeBuffer.position(start);
				while (writeLengthBuffer.hasRemaining())
					writeBuffer.put(writeLengthBuffer.get());
				writeBuffer.position(start + dataLength + shift);
			}

			// If it was a partial write, set the OP_WRITE flag to be notified when more writing can occur.
			if (!writeToSocket()) selectionKey.interestOps(SelectionKey.OP_READ | SelectionKey.OP_WRITE);

			return lengthLength + dataLength;
		}
	}

	public void close () {
		try {
			if (socketChannel != null) {
				socketChannel.close();
				socketChannel = null;
				if (selectionKey != null) selectionKey.selector().wakeup();
			}
		} catch (IOException ex) {
			if (level <= DEBUG) debug("Unable to close TCP connection.", ex);
		}
	}

	public boolean needsKeepAlive () {
		return socketChannel != null && keepAliveTime > 0 && System.currentTimeMillis() - lastCommunicationTime > keepAliveTime;
	}
}
