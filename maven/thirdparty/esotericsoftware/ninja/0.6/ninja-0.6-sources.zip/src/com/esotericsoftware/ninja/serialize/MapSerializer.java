
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Network;

/**
 * Serializes objects that implement the {@link Map} interface.
 * <p>
 * With the default constructor, a map requires a 1-3 byte header. An extra 4 bytes is written for each key/value pair.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class MapSerializer extends Serializer {
	static private final MapSerializer instance = new MapSerializer();

	private Class keyClass;
	private Class valueClass;
	private Serializer keySerializer;
	private Serializer valueSerializer;
	private boolean keysAreNotNull;
	private boolean valuesAreNotNull;

	public MapSerializer () {
	}

	/**
	 * @param keyClass The concrete class of each key. This saves 1 byte per key. Set to null if the class is not known or varies
	 *           per key (default).
	 * @param keysAreNotNull True if keys are not null. This saves 1 byte per key if keyClass is set. False if it is not known
	 *           (default).
	 * @param valueClass The concrete class of each value. This saves 1 byte per value. Set to null if the class is not known or
	 *           varies per value (default).
	 * @param valuesAreNotNull True if values are not null. This saves 1 byte per value if keyClass is set. False if it is not
	 *           known (default).
	 */
	public MapSerializer (Class keyClass, boolean keysAreNotNull, Class valueClass, boolean valuesAreNotNull) {
		this.keyClass = keyClass;
		this.keysAreNotNull = keysAreNotNull;
		keySerializer = keyClass == null ? null : Network.getRegisteredClass(keyClass).serializer;
		this.valueClass = valueClass;
		this.valuesAreNotNull = valuesAreNotNull;
		valueSerializer = valueClass == null ? null : Network.getRegisteredClass(valueClass).serializer;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		Map<Object, Object> map = (Map)object;
		int length = map.size();
		IntSerializer.put(buffer, length, true);
		if (length == 0) return;
		for (Iterator iter = map.entrySet().iterator(); iter.hasNext();) {
			Entry entry = (Entry)iter.next();
			if (keySerializer != null) {
				if (keysAreNotNull)
					keySerializer.writeObjectData(connection, buffer, entry.getKey(), false);
				else
					keySerializer.writeObject(connection, entry.getKey(), buffer);
			} else
				Network.writeClassAndObject(connection, entry.getKey(), buffer);
			if (valueSerializer != null) {
				if (valuesAreNotNull)
					valueSerializer.writeObjectData(connection, buffer, entry.getValue(), false);
				else
					valueSerializer.writeObject(connection, entry.getValue(), buffer);
			} else
				Network.writeClassAndObject(connection, entry.getValue(), buffer);
		}
		if (level <= TRACE) trace("Wrote map: " + object);
	}

	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {
		Map map = (Map)newInstance(type);
		int length = IntSerializer.get(buffer, true);
		if (length == 0) return (T)map;
		for (int i = 0; i < length; i++) {
			Object key;
			if (keySerializer != null) {
				if (keysAreNotNull)
					key = keySerializer.readObjectData(connection, buffer, keyClass, false);
				else
					key = keySerializer.readObject(connection, buffer, keyClass);
			} else
				key = Network.readClassAndObject(connection, buffer);
			Object value;
			if (valueSerializer != null) {
				if (valuesAreNotNull)
					value = valueSerializer.readObjectData(connection, buffer, valueClass, false);
				else
					value = valueSerializer.readObject(connection, buffer, valueClass);
			} else
				value = Network.readClassAndObject(connection, buffer);
			map.put(key, value);
		}
		if (level <= TRACE) trace("Read map: " + map);
		return (T)map;
	}

	static public void put (Connection connection, ByteBuffer buffer, Object object, Class keyClass, boolean keysAreNotNull,
		Class valueClass, boolean valuesAreNotNull) throws SerializationException {
		instance.keyClass = keyClass;
		instance.keysAreNotNull = keysAreNotNull;
		instance.valueClass = valueClass;
		instance.valuesAreNotNull = valuesAreNotNull;
		instance.writeObjectData(connection, buffer, object, false);
	}

	static public <T> T get (Connection connection, ByteBuffer buffer, Class<T> type, Class keyClass, boolean keysAreNotNull,
		Class valueClass, boolean valuesAreNotNull) throws SerializationException {
		instance.keyClass = keyClass;
		instance.keysAreNotNull = keysAreNotNull;
		instance.valueClass = valueClass;
		instance.valuesAreNotNull = valuesAreNotNull;
		return instance.readObjectData(connection, buffer, type, false);
	}
}
