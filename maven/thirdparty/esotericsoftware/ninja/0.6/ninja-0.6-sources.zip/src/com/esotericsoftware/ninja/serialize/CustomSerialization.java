
package com.esotericsoftware.ninja.serialize;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Allows implementing classes to perform their own serialization. Custom serialization can be more efficient in some cases. <br>
 * <br>
 * Custom serialization can make use of any Serializer needed. Eg... <br>
 * <br>
 * public void writeObjectData (Connection connection, ByteBuffer buffer) {<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Serializer.stringSerializer.writeObjectData(connection, stringValue, buffer);<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Serializer.fieldSerializer.writeObjectData(connection, someOtherClassValue, buffer);<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;buffer.putInt(intValue); // Custom serialization.<br>
 * }<br>
 * <br>
 * public void readObjectData (Connection connection, ByteBuffer buffer) {<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;stringValue = Serializer.stringSerializer.readObjectData(connection, buffer, String.class);<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;someOtherClassValue = Serializer.fieldSerializer.readObjectData(connection, buffer,
 * SomeOtherClass.class);<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;intValue = buffer.getInt(); // Custom deserialization.<br>
 * }
 * @see CustomSerializer
 * @author Nathan Sweet <misc@n4te.com>
 */
public interface CustomSerialization {
	public void writeObjectData (Connection connection, ByteBuffer buffer) throws SerializationException;

	public void readObjectData (Connection connection, ByteBuffer buffer) throws SerializationException;
}
