
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes a 1 byte boolean.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class BooleanSerializer extends Serializer {
	public Boolean readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		boolean b = buffer.get() == 1;
		if (level <= TRACE) trace("Read boolean: " + b);
		return b;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		buffer.put((Boolean)object ? (byte)1 : (byte)0);
		if (level <= TRACE) trace("Wrote boolean: " + object);
	}
}
