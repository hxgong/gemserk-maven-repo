
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;
import java.util.Collection;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Network;

/**
 * Serializes objects that implement the {@link Collection} interface.
 * <p>
 * With the default constructor, a collection requires a 1-3 byte header and an extra 2-3 bytes is written for each element in the
 * collection. The alternate constructor can be used to improve efficiency to match using an array.
 * 
 * @author Nathan Sweet <misc@n4te.com>
 */
public class CollectionSerializer extends Serializer {
	static private final CollectionSerializer instance = new CollectionSerializer();

	private boolean elementsAreNotNull;
	private Serializer serializer;
	private Class elementClass;

	public CollectionSerializer () {
	}

	/**
	 * @param elementsAreNotNull True if elements are not null. This saves 1 byte per element if elementClass is set. False if it
	 *           is not known (default).
	 * @param elementClass The concrete class of each element. This saves 1-2 bytes per element. Set to null if the class is not
	 *           known or varies per element (default).
	 */
	public CollectionSerializer (Class elementClass, boolean elementsAreNotNull) {
		this.elementClass = elementClass;
		this.elementsAreNotNull = elementsAreNotNull;
		serializer = elementClass == null ? null : Network.getRegisteredClass(elementClass).serializer;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		Collection collection = (Collection)object;
		int length = collection.size();
		IntSerializer.put(buffer, length, true);
		if (length == 0) return;
		if (serializer != null) {
			if (elementsAreNotNull) {
				for (Object element : collection)
					serializer.writeObjectData(connection, buffer, element, false);
			} else {
				for (Object element : collection)
					serializer.writeObject(connection, element, buffer);
			}
		} else {
			for (Object element : collection)
				Network.writeClassAndObject(connection, element, buffer);
		}
		if (level <= TRACE) trace("Wrote collection: " + object);
	}

	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {
		int length = IntSerializer.get(buffer, true);
		Collection collection = (Collection)newInstance(type);
		if (length == 0) return (T)collection;
		if (serializer != null) {
			if (elementsAreNotNull) {
				for (int i = 0; i < length; i++)
					collection.add(serializer.readObjectData(connection, buffer, elementClass, false));
			} else {
				for (int i = 0; i < length; i++)
					collection.add(serializer.readObject(connection, buffer, elementClass));
			}
		} else {
			for (int i = 0; i < length; i++)
				collection.add(Network.readClassAndObject(connection, buffer));
		}
		if (level <= TRACE) trace("Read collection: " + collection);
		return (T)collection;
	}

	static public void put (Connection connection, ByteBuffer buffer, Collection value, Class elementClass,
		boolean elementsAreNotNull) throws SerializationException {
		instance.elementClass = elementClass;
		instance.elementsAreNotNull = elementsAreNotNull;
		instance.writeObjectData(connection, value, buffer);
	}

	static public Collection get (Connection connection, ByteBuffer buffer, Class elementClass, boolean elementsAreNotNull)
		throws SerializationException {
		instance.elementClass = elementClass;
		instance.elementsAreNotNull = elementsAreNotNull;
		return instance.readObjectData(connection, buffer, null);
	}
}
