
package com.esotericsoftware.ninja;

import static com.esotericsoftware.ninja.Log.*;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.Iterator;
import java.util.Set;

import com.esotericsoftware.ninja.Network.RegisterTCP;
import com.esotericsoftware.ninja.Network.RegisterUDP;
import com.esotericsoftware.ninja.serialize.SerializationException;

/**
 * Represents a TCP and optionally a UDP connection to a {@link Server}.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class Client extends Connection implements EndPoint {
	private Selector selector;
	private boolean udpRegistered;
	private volatile boolean shutdown;
	private Object updateLock = new Object();
	private Thread updateThread;

	/**
	 * Creates a Client with a buffer size of 2048.
	 */
	public Client () {
		this(2048);
	}

	/**
	 * @see Connection#Connection(int)
	 */
	public Client (int bufferSize) {
		super(bufferSize);
		endPoint = this;
		try {
			selector = Selector.open();
		} catch (IOException ex) {
			throw new RuntimeException("Error opening selector.", ex);
		}
	}

	/**
	 * Opens a TCP only client.
	 * @see #connect(int, InetAddress, int, int)
	 */
	public void connect (int timeout, String host, int tcpPort) throws IOException {
		connect(timeout, InetAddress.getByName(host), tcpPort, -1);
	}

	/**
	 * Opens a TCP and UDP client.
	 * @see #connect(int, InetAddress, int, int)
	 */
	public void connect (int timeout, String host, int tcpPort, int udpPort) throws IOException {
		connect(timeout, InetAddress.getByName(host), tcpPort, udpPort);
	}

	/**
	 * Opens a TCP only client.
	 * @see #connect(int, InetAddress, int, int)
	 */
	public void connect (int timeout, InetAddress host, int tcpPort) throws IOException {
		connect(timeout, host, tcpPort, -1);
	}

	/**
	 * Opens a TCP and UDP client. Blocks until the connection is complete or the timeout is reached.
	 * <p>
	 * Because the framework must perform some minimal communication before the connection is considered successful, a separate
	 * thread must be calling {@link #update(int)} during the connection process.
	 * @throws IOException if the server could not be opened or connecting times out.
	 */
	public void connect (int timeout, InetAddress host, int tcpPort, int udpPort) throws IOException {
		if (host == null) throw new IllegalArgumentException("host cannot be null.");
		close();
		try {
			if (udpPort != -1) udp = new UdpConnection(tcp.readBuffer.capacity());

			long endTime;
			synchronized (updateLock) {
				selector.wakeup();
				endTime = System.currentTimeMillis() + timeout;
				tcp.connect(selector, new InetSocketAddress(host, tcpPort), 5000);
			}

			// Wait for RegisterTCP.
			while (System.currentTimeMillis() < endTime && id == -1) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException ignored) {
				}
			}
			if (id == -1) throw new SocketTimeoutException("Connected, but timed out during TCP registration.");

			if (udpPort != -1) {
				InetSocketAddress udpAddress = new InetSocketAddress(host, udpPort);
				synchronized (updateLock) {
					selector.wakeup();
					udp.connect(selector, udpAddress);
				}

				// Wait for RegisterUDP reply.
				int count = 0;
				while (System.currentTimeMillis() < endTime && !udpRegistered) {
					if (count++ % 4 == 0) {
						RegisterUDP registerUDP = new RegisterUDP();
						registerUDP.connectionID = id;
						try {
							udp.send(this, registerUDP, udpAddress);
						} catch (SerializationException ex) {
							IOException ioEx = new IOException();
							ioEx.initCause(ex);
							throw ioEx; // Should never happen.
						}
					}
					try {
						Thread.sleep(50);
					} catch (InterruptedException ignored) {
					}
				}
				if (!udpRegistered) throw new SocketTimeoutException("Connected, but timed out during UDP registration.");
			}
		} catch (IOException ex) {
			close();
			throw ex;
		}
	}

	/**
	 * Reads or writes any pending data for this client. This method will block while the client is being opened via one of the
	 * connect methods.
	 * @param timeout Wait for up to the specified milliseconds for data to be ready to process. May be zero to return immediately
	 *           if there is no data to process.
	 */
	public void update (int timeout) throws IOException, SerializationException {
		updateThread = Thread.currentThread();
		synchronized (updateLock) { // Causes blocking while the selector is used to establish a new connection.
		}
		if (timeout > 0) {
			selector.select(timeout);
		} else {
			selector.selectNow();
		}
		Set<SelectionKey> keys = selector.selectedKeys();
		for (Iterator<SelectionKey> iter = keys.iterator(); iter.hasNext();) {
			SelectionKey selectionKey = iter.next();
			iter.remove();
			int ops = selectionKey.readyOps();
			if ((ops & SelectionKey.OP_READ) == SelectionKey.OP_READ) {
				if (selectionKey.attachment() == tcp) {
					while (true) {
						Object object = tcp.readObject();
						if (object == null) break;
						if (id == -1 || (udp != null && !udpRegistered)) {
							if (object instanceof RegisterTCP) id = ((RegisterTCP)object).connectionID;
							if (object instanceof RegisterUDP) {
								udpRegistered = true;
								if (level <= DEBUG)
									debug("Port " + udp.datagramChannel.socket().getLocalPort() + "/UDP connected to: "
										+ udp.connectedAddress);
							}
							if (id != -1 && (udp == null || udpRegistered)) notifyConnected();
							continue;
						}
						if (level <= DEBUG) debug(this + " received TCP: " + object);
						notifyReceived(object);
					}
				} else {
					if (udp.readFromAddress() == null) continue;
					Object object = udp.readObject(this);
					if (object == null) continue;
					if (level <= DEBUG) debug(this + " received UDP: " + object);
					notifyReceived(object);
				}
			}
			if ((ops & SelectionKey.OP_WRITE) == SelectionKey.OP_WRITE) tcp.writeOperation();
		}
		if (id != -1 && tcp.needsKeepAlive()) sendTCP(Network.keepAlive);
		if (udp != null && udpRegistered && udp.needsKeepAlive()) sendUDP(Network.keepAlive);
	}

	public void run () {
		if (level <= TRACE) trace("Client thread started.");
		shutdown = false;
		while (!shutdown) {
			try {
				update(500);
			} catch (IOException ex) {
				if (level <= TRACE) {
					if (id != -1)
						trace("Unable to update connection: " + this, ex);
					else
						trace("Unable to update connection.", ex);
				} else if (level <= DEBUG) {
					if (id != -1)
						debug(this + " update: " + ex.getMessage());
					else
						debug("Unable to update connection: " + ex.getMessage());
				}
				close();
			} catch (SerializationException ex) {
				if (level <= ERROR) {
					if (id != -1)
						error("Error updating connection: " + this, ex);
					else
						error("Error updating connection.", ex);
				}
				close();
			}
		}
		if (level <= TRACE) trace("Client thread stopped.");
	}

	public void stop () {
		close();
		if (level <= TRACE) trace("Client thread stopping.");
		shutdown = true;
		selector.wakeup();
	}

	public void close () {
		super.close();
		udpRegistered = false;
	}

	public void addListener (Listener listener) {
		super.addListener(listener);
		if (level <= TRACE) trace("Client listener added.");
	}

	public void removeListener (Listener listener) {
		super.removeListener(listener);
		if (level <= TRACE) trace("Client listener removed.");
	}

	/**
	 * Returns true if connected to a {@link Server}. Note this client could become disconnected at any time.
	 */
	public boolean isConnected () {
		return id != -1;
	}

	public Thread getUpdateThread () {
		return updateThread;
	}
}
