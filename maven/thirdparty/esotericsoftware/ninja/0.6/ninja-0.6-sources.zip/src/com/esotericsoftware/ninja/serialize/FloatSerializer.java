
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes a 4 byte float.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class FloatSerializer extends Serializer {
	public Float readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		float f = buffer.getFloat();
		if (level <= TRACE) trace("Read float: " + f);
		return f;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		buffer.putFloat((Float)object);
		if (level <= TRACE) trace("Wrote float: " + object);
	}
}
