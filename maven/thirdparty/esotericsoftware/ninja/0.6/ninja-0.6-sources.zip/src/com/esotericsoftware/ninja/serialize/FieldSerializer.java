
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Network;

/**
 * Serializes objects using direct field assignment. This is the most efficient mechanism for serializing objects, often as good
 * as {@link CustomSerialization}. FieldSerializer is many times smaller and faster than Java serialization.
 * <p>
 * FieldSerializer does not write header data, only the object data is stored. If the type of a field is not final (note
 * primitives are final) then an extra byte is written for that field.
 * 
 * @see Serializer
 * @see Network#register(Class)
 * 
 * @author Nathan Sweet <misc@n4te.com>
 */
public class FieldSerializer extends Serializer {
	static private final FieldSerializer instance = new FieldSerializer();

	private boolean fieldsAreNotNull, setFieldsAsAccessible;
	private final HashMap<Class, CachedField[]> fieldCache = new HashMap();

	public FieldSerializer () {
	}

	/**
	 * @param fieldsAreNotNull True if none of the fields are null. Saves 1 byte per field. False if it is not known (default).
	 * @param setFieldsAsAccessible If true, all fields (inlcuding private fields) will be serializes and
	 *           {@link Field#setAccessible(boolean) set as accessible} (default). If false, only fields in the public API will be
	 *           serialized.
	 */
	public FieldSerializer (boolean fieldsAreNotNull, boolean setFieldsAsAccessible) {
		this.fieldsAreNotNull = fieldsAreNotNull;
		this.setFieldsAsAccessible = setFieldsAsAccessible;
	}

	private CachedField[] cache (Class type) {
		if (type.isInterface()) return new CachedField[0]; // No fields to serialize.
		ArrayList<Field> allFields = new ArrayList();
		Class nextClass = type;
		while (nextClass != Object.class) {
			Collections.addAll(allFields, nextClass.getDeclaredFields());
			nextClass = nextClass.getSuperclass();
		}
		PriorityQueue<CachedField> cachedFields = new PriorityQueue(Math.max(1, allFields.size()), new Comparator<CachedField>() {
			public int compare (CachedField o1, CachedField o2) {
				// Fields are sorted by alpha so the order of the data is known and doesn't have to be sent across the wire.
				return o1.field.getName().compareTo(o2.field.getName());
			}
		});
		for (int i = 0, n = allFields.size(); i < n; i++) {
			Field field = allFields.get(i);
			int modifiers = field.getModifiers();
			if (Modifier.isTransient(modifiers)) continue;
			if (Modifier.isFinal(modifiers)) continue;
			if (Modifier.isStatic(modifiers)) continue;
			if (field.isSynthetic()) continue;
			if (setFieldsAsAccessible)
				field.setAccessible(true);
			else if (Modifier.isPrivate(modifiers)) {
				continue;
			}

			CachedField cachedField = new CachedField();
			cachedField.field = field;
			cachedField.canBeNull = !field.isAnnotationPresent(NonNull.class);

			// Always use the same serializer for this field if the field's class is final (note: primitives are final).
			Class fieldClass = field.getType();
			if (Modifier.isFinal(fieldClass.getModifiers()))
				cachedField.serializer = Network.getRegisteredClass(fieldClass).serializer;

			cachedFields.add(cachedField);
		}
		CachedField[] cachedFieldArray = cachedFields.toArray(new CachedField[cachedFields.size()]);
		fieldCache.put(type, cachedFieldArray);
		return cachedFieldArray;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		try {
			CachedField[] fields = fieldCache.get(object.getClass());
			if (fields == null) fields = cache(object.getClass());
			for (int i = 0, n = fields.length; i < n; i++) {
				CachedField cachedField = fields[i];
				if (level <= TRACE) trace("Writing field: " + cachedField + " (" + object.getClass().getName() + ")");
				Object value = cachedField.field.get(object);
				Serializer serializer = cachedField.serializer;
				if (serializer != null) {
					if (fieldsAreNotNull || !cachedField.canBeNull)
						serializer.writeObjectData(connection, buffer, value, false);
					else
						serializer.writeObject(connection, value, buffer);
				} else
					Network.writeClassAndObject(connection, value, buffer);
			}
		} catch (IllegalAccessException ex) {
			throw new SerializationException("Error accessing field in class: " + object.getClass().getName(), ex);
		}
		if (level <= TRACE) trace("Wrote object: " + object);
	}

	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {
		T object = newInstance(type);
		try {
			CachedField[] fields = fieldCache.get(object.getClass());
			if (fields == null) fields = cache(object.getClass());
			for (int i = 0, n = fields.length; i < n; i++) {
				CachedField cachedField = fields[i];
				if (level <= TRACE) trace("Reading field: " + cachedField + " (" + object.getClass().getName() + ")");
				Object value;
				Field field = cachedField.field;
				Serializer serializer = cachedField.serializer;
				if (serializer != null) {
					if (fieldsAreNotNull || !cachedField.canBeNull)
						value = serializer.readObjectData(connection, buffer, field.getType(), false);
					else
						value = serializer.readObject(connection, buffer, field.getType());
				} else
					value = Network.readClassAndObject(connection, buffer);
				field.set(object, value);
			}
		} catch (IllegalAccessException ex) {
			throw new SerializationException("Error accessing field in class: " + type.getName(), ex);
		}
		if (level <= TRACE) trace("Read object: " + object);
		return object;
	}

	/**
	 * Allows options to be set for a specific field.
	 * @param serializer The serializer to use for the field's value.
	 * @param canBeNull False if the field can never be null when it is serialized.
	 */
	public void setField (Class type, String fieldName, Serializer serializer, boolean canBeNull) {
		CachedField[] fields = fieldCache.get(type);
		if (fields == null) fields = cache(type);
		for (CachedField cachedField : fields) {
			if (cachedField.field.getName().equals(fieldName)) {
				cachedField.serializer = serializer;
				cachedField.canBeNull = canBeNull;
				break;
			}
		}
	}

	static class CachedField {
		public Field field;
		public Serializer serializer;
		public boolean canBeNull;

		public String toString () {
			return field.getName();
		}
	}

	static public void put (Connection connection, ByteBuffer buffer, Object object, boolean fieldsAreNotNull,
		boolean setFieldsAsAccessible) throws SerializationException {
		instance.fieldsAreNotNull = fieldsAreNotNull;
		instance.setFieldsAsAccessible = setFieldsAsAccessible;
		instance.writeObjectData(connection, buffer, object, false);
	}

	static public <T> T get (Connection connection, ByteBuffer buffer, Class<T> type, boolean fieldsAreNotNull,
		boolean setFieldsAsAccessible) throws SerializationException {
		instance.fieldsAreNotNull = fieldsAreNotNull;
		instance.setFieldsAsAccessible = setFieldsAsAccessible;
		return instance.readObjectData(connection, buffer, type, false);
	}
}
