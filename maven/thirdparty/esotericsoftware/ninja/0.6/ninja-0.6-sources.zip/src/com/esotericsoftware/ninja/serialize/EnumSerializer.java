
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes a 1-3 byte enum.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class EnumSerializer extends Serializer {
	static private final EnumSerializer instance = new EnumSerializer();

	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {
		T[] enumConstants = type.getEnumConstants();
		if (enumConstants == null) throw new SerializationException("Class is not an enum: " + type.getName());
		int ordinal = IntSerializer.get(buffer, true);
		if (ordinal < 0 || ordinal > enumConstants.length - 1)
			throw new SerializationException("Invalid ordinal for enum \"" + type.getName() + "\": " + ordinal);
		if (level <= TRACE) trace("Read enum: " + enumConstants[ordinal]);
		return enumConstants[ordinal];
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		IntSerializer.put(buffer, ((Enum)object).ordinal(), true);
		if (level <= TRACE) trace("Wrote enum: " + object);
	}

	static public void put (ByteBuffer buffer, Enum value) throws SerializationException {
		instance.writeObjectData(null, value, buffer);
	}

	static public Enum get (ByteBuffer buffer) throws SerializationException {
		return instance.readObjectData(null, buffer, null);
	}
}
