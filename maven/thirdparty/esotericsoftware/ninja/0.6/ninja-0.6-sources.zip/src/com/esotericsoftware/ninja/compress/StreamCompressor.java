
package com.esotericsoftware.ninja.compress;

import java.io.FilterInputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;

/**
 * Convenience class to compress and decompress using streams.
 * @author Nathan Sweet <misc@n4te.com>
 */
public abstract class StreamCompressor extends ByteArrayCompressor {
	private ByteArrayOutputStream outputBufferStream = new ByteArrayOutputStream(outputBuffer);
	private ByteArrayInputStream inputBufferStream = new ByteArrayInputStream(inputBuffer);

	/**
	 * @see ByteArrayCompressor#ByteArrayCompressor(Serializer)
	 */
	public StreamCompressor (Serializer serializer) {
		super(serializer);
	}

	/**
	 * @see ByteArrayCompressor#ByteArrayCompressor(Serializer, int)
	 */
	public StreamCompressor (Serializer serializer, int bufferSize) {
		super(serializer, bufferSize);
	}

	public final int compress (int inputLength) throws SerializationException {
		outputBufferStream.reset();
		try {
			FilterOutputStream output = getCompressionStream(outputBufferStream);
			try {
				output.write(inputBuffer, 0, inputLength);
			} finally {
				output.close();
			}
		} catch (IOException ex) {
			throw new SerializationException(ex);
		}
		return outputBufferStream.size();
	}

	abstract public FilterOutputStream getCompressionStream (OutputStream output);

	public final int decompress (int inputLength) throws SerializationException {
		inputBufferStream.reset();
		inputBufferStream.setCount(inputLength);
		try {
			FilterInputStream input = getDecompressionStream(inputBufferStream);
			try {
				return input.read(outputBuffer, 0, outputBuffer.length);
			} finally {
				input.close();
			}
		} catch (IOException ex) {
			throw new SerializationException(ex);
		}
	}

	abstract public FilterInputStream getDecompressionStream (InputStream input);

	static private class ByteArrayOutputStream extends java.io.ByteArrayOutputStream {
		public ByteArrayOutputStream (byte[] buf) {
			super(0);
			this.buf = buf;
		}
	}

	static private class ByteArrayInputStream extends java.io.ByteArrayInputStream {
		public ByteArrayInputStream (byte[] buf) {
			super(buf);
		}

		public void setCount (int count) {
			this.count = count;
		}
	}
}
