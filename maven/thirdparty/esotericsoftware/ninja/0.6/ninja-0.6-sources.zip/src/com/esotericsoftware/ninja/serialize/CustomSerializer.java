
package com.esotericsoftware.ninja.serialize;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * @see CustomSerialization
 * @author Nathan Sweet <misc@n4te.com>
 */
public class CustomSerializer extends Serializer {
	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException {
		T object = newInstance(type);
		((CustomSerialization)object).readObjectData(connection, buffer);
		return object;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		((CustomSerialization)object).writeObjectData(connection, buffer);
	}
}
