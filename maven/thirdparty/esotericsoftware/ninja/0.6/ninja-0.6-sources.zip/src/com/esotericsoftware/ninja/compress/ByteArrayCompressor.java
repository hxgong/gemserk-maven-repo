
package com.esotericsoftware.ninja.compress;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.serialize.SerializationException;
import com.esotericsoftware.ninja.serialize.Serializer;

/**
 * Convenience class to compress and decompress using byte arrays. Note there are memory copies involved, but compression and/or
 * encoding generally trades some performance for network bandwidth anyway.
 * @author Nathan Sweet <misc@n4te.com>
 */
public abstract class ByteArrayCompressor extends Compressor {
	protected byte[] inputBuffer;
	protected byte[] outputBuffer;
	private ByteBuffer decompressBuffer;

	/**
	 * Creates a ByteArrayCompressor with a buffer size of 2048.
	 */
	public ByteArrayCompressor (Serializer serializer) {
		this(serializer, 2048);
	}

	/**
	 * @param bufferSize The maximum size a serialized object may be before or after compression.
	 */
	public ByteArrayCompressor (Serializer serializer, int bufferSize) {
		super(serializer);
		outputBuffer = new byte[bufferSize];
		inputBuffer = new byte[bufferSize];
		decompressBuffer = ByteBuffer.wrap(outputBuffer);
	}

	public final void compress (Connection connection, Object object, ByteBuffer buffer) throws SerializationException {
		int start = buffer.position();

		int inputLength = buffer.remaining();
		buffer.get(inputBuffer, 0, inputLength);
		int outputLength = compress(connection, inputLength);

		// Replace data.
		buffer.position(start);
		buffer.limit(buffer.capacity());
		buffer.put(outputBuffer, 0, outputLength);
	}

	/**
	 * Implementations should read the specified number of bytes from {@link #inputBuffer} and write compressed data to
	 * {@link #outputBuffer}.
	 * @return the number of bytes written to {@link #outputBuffer} or -1 if the object should not be sent.
	 */
	abstract public int compress (Connection connection, int inputLength) throws SerializationException;

	public final ByteBuffer decompress (Connection connection, ByteBuffer buffer, Class type) throws SerializationException {
		int inputLength = buffer.remaining();
		buffer.get(inputBuffer, 0, inputLength);
		int outputLength = decompress(connection, inputLength);

		decompressBuffer.position(0);
		decompressBuffer.limit(outputLength);
		return decompressBuffer;
	}

	/**
	 * Implementations should read the specified number of bytes from {@link #inputBuffer} and write decompressed data to
	 * {@link #outputBuffer}.
	 * @return the number of bytes written to {@link #outputBuffer}.
	 */
	abstract public int decompress (Connection connection, int inputLength) throws SerializationException;
}
