
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.lang.reflect.Constructor;
import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;
import com.esotericsoftware.ninja.Network;

/**
 * Serializes objects to bytes and deserializes objects from bytes.
 * @see Network#register(Class, Serializer)
 * @author Nathan Sweet <misc@n4te.com>
 */
abstract public class Serializer {
	private boolean canBeNull = true;

	/**
	 * When true, a byte will never be used to denote if the object is null. This is useful for primitives and objects that are
	 * known to never be null. Defaults to true.
	 */
	public void setCanBeNull (boolean canBeNull) {
		this.canBeNull = canBeNull;
	}

	/**
	 * Writes the object to the buffer. If the object is not a primitive, first a byte is written to denote if the object is null.
	 * This method should be used when the class will be known at the time the object is to be read from the buffer. Otherwise
	 * {@link Network#writeClassAndObject(Connection, Object, ByteBuffer)} should be used.
	 * @param object Can be null.
	 * @throws SerializationException if the object could not be written.
	 */
	public final void writeObject (Connection connection, Object object, ByteBuffer buffer) throws SerializationException {
		if (canBeNull) {
			if (object == null) {
				if (level <= TRACE) trace("Wrote object: null");
				buffer.put((byte)0);
				return;
			}
			buffer.put((byte)1);
		}
		writeObjectData(connection, buffer, object, false);
	}

	/**
	 * Writes the data for the object to the buffer. This should be used only when the object to be written cannot be null.
	 * Otherwise use {@link #writeObject(Connection, Object, ByteBuffer)}.
	 * @param object Guaranteed to be non-null.
	 * @param lengthKnown True if the length of the data written to the buffer will automatically be known when it is read back.
	 *           Eg, this is true when the object is the root of the object graph or if an object will be compressed.
	 */
	public abstract void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException;

	/**
	 * Calls {@link #writeObjectData(Connection, ByteBuffer, Object, boolean)} with lengthKnown set to false.
	 */
	public void writeObjectData (Connection connection, Object object, ByteBuffer buffer) throws SerializationException {
		writeObjectData(connection, buffer, object, false);
	}

	/**
	 * Reads an object from the buffer. Counterpart to {@link #writeObject(Connection, Object, ByteBuffer)}.
	 * @param type The type of the object to be read.
	 * @return The object, or null.
	 */
	public final <T> T readObject (Connection connection, ByteBuffer buffer, Class<T> type) throws SerializationException {
		if (canBeNull && buffer.get() == 0) {
			if (level <= TRACE) trace("Read object: null");
			return null;
		}
		return readObjectData(connection, buffer, type, false);
	}

	/**
	 * Reads the data for the object from the buffer. Counterpart to
	 * {@link #writeObjectData(Connection, ByteBuffer, Object, boolean)}.
	 * @param buffer Guaranteed to contain data for a non-null object.
	 * @param type The type of the object to be read.
	 * @param lengthKnown True if the buffer's limit is set to the length of the data representing the object to read. Eg, this is
	 *           true when the object is the root of the object graph or when the object has been decompressed.
	 */
	abstract public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type, boolean lengthKnown)
		throws SerializationException;

	/**
	 * Calls {@link #readObjectData(Connection, ByteBuffer, Class, boolean)} with lengthKnown set to false.
	 */
	public <T> T readObjectData (Connection connection, ByteBuffer buffer, Class<T> type) throws SerializationException {
		return readObjectData(connection, buffer, type, false);
	}

	/**
	 * Returns an instance of the specified class.
	 * @throws SerializationException if the class could not be constructed.
	 */
	public <T> T newInstance (Class<T> type) throws SerializationException {
		try {
			return type.newInstance();
		} catch (Exception ex) {
			if (ex instanceof InstantiationException) {
				Constructor[] constructors = type.getConstructors();
				boolean hasZeroArgConstructor = false;
				for (int i = 0, n = constructors.length; i < n; i++) {
					Constructor constructor = constructors[i];
					if (constructor.getParameterTypes().length == 0) {
						hasZeroArgConstructor = true;
						break;
					}
				}
				if (!hasZeroArgConstructor)
					throw new SerializationException("Class cannot be created (missing no-arg constructor): " + type.getName(), ex);
			}
			throw new SerializationException("Error constructing instance of class: " + type.getName(), ex);
		}
	}

	/**
	 * Writes a byte indicating if the object is null.
	 * @return true if the object is not null.
	 */
	static public boolean writeNull (ByteBuffer buffer, Object object) {
		if (object == null) {
			if (level <= TRACE) trace("Wrote object: null");
			buffer.put((byte)0);
			return false;
		}
		buffer.put((byte)1);
		return true;
	}

	/**
	 * Reads a byte indicating if the object is null.
	 * @return true if the object is not null.
	 */
	static public boolean readNull (ByteBuffer buffer) {
		if (buffer.get() == 0) {
			if (level <= TRACE) trace("Read object: null");
			return false;
		}
		return true;
	}
}
