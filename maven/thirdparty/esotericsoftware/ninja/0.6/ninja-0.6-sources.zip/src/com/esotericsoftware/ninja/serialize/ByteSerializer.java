
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Writes 1 byte.
 * @author Nathan Sweet <misc@n4te.com>
 */
public class ByteSerializer extends Serializer {
	public Byte readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		byte b = buffer.get();
		if (level <= TRACE) trace("Read byte: " + b);
		return b;
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		buffer.put((Byte)object);
		if (level <= TRACE) trace("Wrote byte: " + object);
	}

	/**
	 * Writes the specified non-negative int to the buffer, cast as a byte.
	 */
	static public void putUnsigned (ByteBuffer buffer, int value) {
		if (value < 0) throw new IllegalArgumentException("value cannot be less than zero: " + value);
		buffer.put((byte)value);
	}

	/**
	 * Reads a non-negative byte from the buffer that was written with {@link #putUnsigned(ByteBuffer, int)}.
	 */
	static public int getUnsigned (ByteBuffer buffer) {
		byte value = buffer.get();
		if (value < 0) return value + 256;
		return value;
	}
}
