
package com.esotericsoftware.ninja.serialize;

import static com.esotericsoftware.ninja.Log.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.BufferOverflowException;
import java.nio.ByteBuffer;

import com.esotericsoftware.ninja.Connection;

/**
 * Serializes objects using Java's built in serialization mechanism. Note that this is very inefficient and should be avoided if
 * possible.
 * 
 * @see Serializer
 * @see FieldSerializer
 * @see BeanSerializer
 * 
 * @author Nathan Sweet <misc@n4te.com>
 */
public class SerializableSerializer extends Serializer {
	static private final SerializableSerializer instance = new SerializableSerializer();

	public Object readObjectData (Connection connection, ByteBuffer buffer, Class type, boolean lengthKnown)
		throws SerializationException {
		int length = IntSerializer.get(buffer, true);
		byte[] array = new byte[length];
		buffer.get(array);
		try {
			Object object = new ObjectInputStream(new ByteArrayInputStream(array)).readObject();
			if (level <= TRACE) trace("Read object: " + object);
			return object;
		} catch (Exception ex) {
			throw new SerializationException("Error during Java deserialization.", ex);
		}
	}

	public void writeObjectData (Connection connection, ByteBuffer buffer, Object object, boolean lengthKnown)
		throws SerializationException {
		try {
			ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
			ObjectOutputStream objectStream = new ObjectOutputStream(byteStream);
			objectStream.writeObject(object);
			objectStream.close();
			byte[] array = byteStream.toByteArray();
			IntSerializer.put(buffer, array.length, true);
			buffer.put(array);
		} catch (BufferOverflowException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new SerializationException("Error during Java serialization.", ex);
		}
		if (level <= TRACE) trace("Wrote object: " + object);
	}

	static public void put (ByteBuffer buffer, Object object) throws SerializationException {
		instance.writeObjectData(null, object, buffer);
	}

	static public <T> T get (ByteBuffer buffer, Class<T> type) throws SerializationException {
		return instance.readObjectData(null, buffer, type);
	}
}
